#!/bin/bash

# bash installFontawesome.sh pour lancer le script

npm i --save @fortawesome/fontawesome-svg-core
npm i --save @fortawesome/free-solid-svg-icons
npm i --save @fortawesome/free-regular-svg-icons
npm i --save @fortawesome/free-brands-svg-icons
npm i --save @fortawesome/react-fontawesome@latest

# import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
# import { faXmark } from "@fortawesome/free-solid-svg-icons";

# <FontAwesomeIcon icon={faXmark} />

